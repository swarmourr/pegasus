TODO
====

Ensemble Manager
----------------
* User guide documentation
* Add dashboard UI for monitoring ensembles
* API documentation
* Add workflow abort command
* Add ensemble hold command (requires pegasus-hold)
* Add workflow dependencies
* Implement global max\_planning and max\_running
* Implement max\_failures\_pause
* Implement run\_after date
* Implement email notifications
* Work out security isolation of running workflows
* Update pegasus-archive so that it updates ensemble_workflow
* Enable remote planning and execution?

