Google APIs common protos
-------------------------

.. image:: https://img.shields.io/pypi/v/googleapis-common-protos.svg
    :target: https://pypi.org/project/googleapis-common-protos/


googleapis-common-protos contains the python classes generated from the common
protos in the `googleapis/googleapis <https://github.com/googleapis/googleapis>`_ repository.
